import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import sqlite3, pandas as pd, numpy as np, matplotlib.pyplot as plt
from datetime import datetime

class Database:
    def __init__(self, path="coffee.db"):
        self.conn = sqlite3.connect(path)
        self.conn.execute('''CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            coffee_type TEXT, sweetener TEXT, quantity_sold INT,
            unit_price REAL, unit_cost REAL, sale_date TEXT,
            water_quantity_rating TEXT, comments TEXT)''')
        self.conn.commit()

    def insert_sale(self, record):
        self.conn.execute('''INSERT INTO sales (
            coffee_type, sweetener, quantity_sold, unit_price,
            unit_cost, sale_date, water_quantity_rating, comments)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)''', record)
        self.conn.commit()

    def fetch_all(self):
        return pd.read_sql_query("SELECT * FROM sales", self.conn)

class Analyzer:
    def __init__(self, df):
        self.df = df.copy()
        self.df['sale_date'] = pd.to_datetime(self.df['sale_date'], errors='coerce')

    def hourly_analysis(self):
        self.df['hour'] = self.df['sale_date'].dt.hour
        hourly = self.df.groupby(['hour', 'coffee_type'])['quantity_sold'].sum().unstack(fill_value=0)
        hourly.plot(kind='bar', stacked=True, figsize=(9,4), title="Hourly Coffee Sales")
        plt.xlabel("Hour"); plt.ylabel("Quantity Sold"); plt.tight_layout(); plt.show()
        for hour in hourly.index:
            filter_qty = hourly.loc[hour].get('Filter', 0)
            other_qty = hourly.loc[hour].sum() - filter_qty
            result = "Filter" if filter_qty > other_qty else "Normal" if filter_qty < other_qty else "Balanced"
            print(f"🕒 Hour {hour}: Prepare more {result} coffee.")

    def feedback_suggestions(self):
        print("💬 Feedback Suggestions:")
        for c in self.df['comments'].dropna():
            cl = c.lower()
            if "watery" in cl or "diluted" in cl:
                print(f"- '{c}' ➜ Reduce water ratio")
            elif "strong" in cl or "bitter" in cl:
                print(f"- '{c}' ➜ Soften brew or reduce strength")
            elif "cold" in cl:
                print(f"- '{c}' ➜ Adjust serving temperature")

    def profit_report(self):
        self.df['profit'] = (self.df['unit_price'] - self.df['unit_cost']) * self.df['quantity_sold']
        self.df['month'] = self.df['sale_date'].dt.to_period("M")
        monthly = self.df.groupby(['month','coffee_type'])[['quantity_sold','profit']].sum()
        print("\n📈 Monthly Profit Report:\n", monthly)
        self.df.groupby('coffee_type')['profit'].sum().plot(kind='bar', color='teal', title="Total Profit by Coffee Type")
        plt.ylabel("₹"); plt.tight_layout(); plt.show()

class CoffeeApp:
    def __init__(self, root):
        self.db = Database()
        self.root = root
        self.root.title("Kings Coffee Analyzer")
        self.inputs = {}; self.build_gui()

    def build_gui(self):
        fields = ["Coffee Type","Sweetener","Quantity","Unit Price","Unit Cost","Date","Rating","Comments"]
        for i, label in enumerate(fields):
            ttk.Label(self.root, text=label).grid(row=i, column=0)
            e = ttk.Entry(self.root, width=25); e.grid(row=i, column=1); self.inputs[label] = e
        self.inputs["Date"].insert(0, datetime.now().strftime('%Y-%m-%d %H:%M'))

        actions = [("Save Entry", self.save_entry), ("Import CSV", self.import_csv),
                   ("Hourly Analysis", self.run_hourly), ("Feedback Suggestions", self.run_feedback),
                   ("Monthly Profit", self.run_profit)]
        for i, (text, cmd) in enumerate(actions, start=8):
            ttk.Button(self.root, text=text, command=cmd).grid(row=i, column=0, columnspan=2, pady=3)

    def save_entry(self):
        try:
            r = (self.inputs["Coffee Type"].get(), self.inputs["Sweetener"].get(),
                 int(self.inputs["Quantity"].get()), float(self.inputs["Unit Price"].get()),
                 float(self.inputs["Unit Cost"].get()), self.inputs["Date"].get(),
                 self.inputs["Rating"].get(), self.inputs["Comments"].get())
            self.db.insert_sale(r); messagebox.showinfo("Saved", "Entry stored.")
            [self.inputs[k].delete(0, tk.END) for k in self.inputs]; self.inputs["Date"].insert(0, datetime.now().strftime('%Y-%m-%d %H:%M'))
        except Exception as e: messagebox.showerror("Error", f"Failed to save:\n{e}")

    def import_csv(self):
        path = filedialog.askopenfilename(title="Select CSV", filetypes=[("CSV Files","*.csv")])
        try:
            df = pd.read_csv(path); cols = ['coffee_type','sweetener','quantity_sold','unit_price','unit_cost','sale_date','water_quantity_rating','comments']
            if not all(c in df.columns for c in cols): messagebox.showerror("Error", "Missing columns"); return
            for _, r in df.iterrows(): self.db.insert_sale(tuple(r[c] for c in cols))
            messagebox.showinfo("Imported", "CSV data added.")
        except Exception as e: messagebox.showerror("Error", f"Import failed:\n{e}")

    def run_hourly(self): Analyzer(self.db.fetch_all()).hourly_analysis()
    def run_feedback(self): Analyzer(self.db.fetch_all()).feedback_suggestions()
    def run_profit(self): Analyzer(self.db.fetch_all()).profit_report()

if __name__ == "__main__":
    root = tk.Tk(); CoffeeApp(root); root.mainloop()
